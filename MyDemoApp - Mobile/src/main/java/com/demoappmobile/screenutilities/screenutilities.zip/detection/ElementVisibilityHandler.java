package com.demoappmobile.screenutilities.detection;

import com.demoappmobile.Logger.ErrorMessage;
import com.demoappmobile.Logger.InfoMessage;
import com.demoappmobile.screenutilities.detection.wait.element.WaitForAllElements;
import com.demoappmobile.screenutilities.detection.wait.element.WaitForFirstElement;
import com.demoappmobile.screenutilities.detection.wait.locator.WaitForAllLocators;
import com.demoappmobile.screenutilities.detection.wait.locator.WaitForFirstLocator;
import com.demoappmobile.screenutilities.driver.DriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Handles the visibility checks of web elements and locators within a web page. It provides
 * methods to wait for the visibility of elements or locators, either individually or in groups,
 * before proceeding with further actions or assertions in automated tests.
 */
public class ElementVisibilityHandler {

    private final WebDriverWait webDriverWait = DriverManager.getInstance().getWebDriverWait();

    /**
     * Waits for all specified web elements to become visible.
     *
     * @param webElements The web elements to check.
     * @return True if all elements are visible, false otherwise.
     */
    public boolean areAllElementsVisible(WebElement... webElements) {
        return WaitForAllElements.waitForVisibilityOfAllElements(DriverManager.getInstance()
                                                                              .getFluentWait(), webElements);
    }

    /**
     * Waits for all specified web elements to become visible within a given polling interval.
     *
     * @param pollingInterval The interval to poll for element visibility.
     * @param webElements     The web elements to check.
     * @return True if all elements are visible, false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsVisible(Duration pollingInterval, WebElement... webElements) {
        return WaitForAllElements.waitForVisibilityOfAllElements(
                DriverManager.getInstance().getFluentWait(pollingInterval), webElements);
    }

    /**
     * Waits for all specified web elements to become visible within a specified timeout and polling interval.
     *
     * @param timeout         The maximum time to wait for the elements to become visible.
     * @param pollingInterval The interval to poll for element visibility.
     * @param webElements     The web elements to check.
     * @return True if all elements are visible, false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsVisible(Duration timeout, Duration pollingInterval, WebElement... webElements) {
        return WaitForAllElements.waitForVisibilityOfAllElements(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), webElements);
    }

    /**
     * Waits for all web elements in the provided list to become visible.
     *
     * @param webElementsList The list of web elements to check.
     * @return True if all elements in the list are visible, false otherwise.
     */
    public boolean areAllElementsVisible(List<WebElement> webElementsList) {
        return WaitForAllElements.waitForVisibilityOfAllElements(DriverManager.getInstance()
                                                                               .getFluentWait(), webElementsList);
    }

    /**
     * Checks if all elements in the given list are visible, considering a specific polling interval.
     *
     * @param pollingInterval Custom polling interval.
     * @param webElementsList List of web elements to check for visibility.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsVisible(Duration pollingInterval, List<WebElement> webElementsList) {
        return WaitForAllElements.waitForVisibilityOfAllElements(
                DriverManager.getInstance().getFluentWait(pollingInterval), webElementsList);
    }

    /**
     * Checks if all elements in the given list are visible, considering both a custom timeout and polling interval.
     *
     * @param timeout         Custom timeout.
     * @param pollingInterval Custom polling interval.
     * @param webElementsList List of web elements to check for visibility.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsVisible(Duration timeout, Duration pollingInterval, List<WebElement> webElementsList) {
        return WaitForAllElements.waitForVisibilityOfAllElements(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), webElementsList);
    }

    /**
     * Checks if elements identified by the given locators are all visible.
     *
     * @param locators Locators identifying the elements to check.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    public boolean areAllElementsByLocatorsVisible(By... locators) {
        return WaitForAllLocators.waitForEachLocatorToBeVisibleOnce(DriverManager.getInstance()
                                                                                  .getFluentWait(), locators);
    }

    /**
     * Checks if elements identified by the given locators are all visible, considering a specific polling interval.
     *
     * @param pollingInterval Custom polling interval.
     * @param locators        Locators identifying the elements to check.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsByLocatorsVisible(Duration pollingInterval, By... locators) {
        return WaitForAllLocators.waitForEachLocatorToBeVisibleOnce(
                DriverManager.getInstance().getFluentWait(pollingInterval), locators);
    }

    /**
     * Checks if elements identified by the given locators are all visible,
     * considering both a custom timeout and polling interval.
     *
     * @param timeout         Custom timeout.
     * @param pollingInterval Custom polling interval.
     * @param locators        Locators identifying the elements to check.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsByLocatorsVisible(Duration timeout, Duration pollingInterval, By... locators) {
        return WaitForAllLocators.waitForEachLocatorToBeVisibleOnce(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), locators);
    }

    /**
     * Checks if all elements identified by the given locators are visible.
     *
     * @param locatorsList List of locators identifying the elements to check.
     * @return true if all elements become visible within the default wait time; false otherwise.
     */
    public boolean areAllElementsByLocatorsVisible(List<By> locatorsList) {
        return WaitForAllLocators.waitForEachLocatorToBeVisibleOnce(
                DriverManager.getInstance().getFluentWait(), locatorsList);
    }

    /**
     * Checks if all elements identified by the given locators are visible, considering a specific polling interval.
     *
     * @param pollingInterval Custom polling interval.
     * @param locatorsList    List of locators identifying the elements to check.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsByLocatorsVisible(Duration pollingInterval, List<By> locatorsList) {
        return WaitForAllLocators.waitForEachLocatorToBeVisibleOnce(
                DriverManager.getInstance().getFluentWait(pollingInterval), locatorsList);
    }

    /**
     * Checks if all elements identified by the given locators are visible,
     * considering both a custom timeout and polling interval.
     *
     * @param timeout         Custom timeout.
     * @param pollingInterval Custom polling interval.
     * @param locatorsList    List of locators identifying the elements to check.
     * @return true if all elements become visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean areAllElementsByLocatorsVisible(Duration timeout, Duration pollingInterval, List<By> locatorsList) {
        return WaitForAllLocators.waitForEachLocatorToBeVisibleOnce(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), locatorsList);
    }

    /**
     * Checks if any of the specified elements are visible.
     *
     * @param webElements Elements to check for visibility.
     * @return true if any of the elements are visible; false otherwise.
     */
    public boolean isAnyElementVisible(WebElement... webElements) {
        return WaitForFirstElement.waitForVisibilityOfFirstElement(DriverManager.getInstance()
                                                                                 .getFluentWait(), webElements);
    }

    /**
     * Checks if any of the specified elements are visible, considering a specific polling interval.
     *
     * @param pollingInterval Custom polling interval.
     * @param webElements     Elements to check for visibility.
     * @return true if any of the elements are visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementVisible(Duration pollingInterval, WebElement... webElements) {
        return WaitForFirstElement.waitForVisibilityOfFirstElement(
                DriverManager.getInstance().getFluentWait(pollingInterval), webElements);
    }

    /**
     * Checks if any of the specified elements are visible, considering both a custom timeout and polling interval.
     *
     * @param timeout         Custom timeout.
     * @param pollingInterval Custom polling interval.
     * @param webElements     Elements to check for visibility.
     * @return true if any of the elements are visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementVisible(Duration timeout, Duration pollingInterval, WebElement... webElements) {
        return WaitForFirstElement.waitForVisibilityOfFirstElement(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), webElements);
    }

    /**
     * Checks if any element from a list of elements is visible.
     *
     * @param webElementsList List of elements to check for visibility.
     * @return true if any of the elements in the list are visible; false otherwise.
     */
    public boolean isAnyElementVisible(List<WebElement> webElementsList) {
        return WaitForFirstElement.waitForVisibilityOfFirstElement(
                DriverManager.getInstance().getFluentWait(), webElementsList);
    }

    /**
     * Checks if any element from a list of elements is visible, considering a specific polling interval.
     *
     * @param pollingInterval Custom polling interval.
     * @param webElementsList List of elements to check for visibility.
     * @return true if any of the elements in the list are visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementVisible(Duration pollingInterval, List<WebElement> webElementsList) {
        return WaitForFirstElement.waitForVisibilityOfFirstElement(
                DriverManager.getInstance().getFluentWait(pollingInterval), webElementsList);
    }

    /**
     * Checks if any element from a list of elements is visible, considering both a custom timeout and polling interval.
     *
     * @param timeout         Custom timeout.
     * @param pollingInterval Custom polling interval.
     * @param webElementsList List of elements to check for visibility.
     * @return true if any of the elements in the list are visible within the wait time; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementVisible(Duration timeout, Duration pollingInterval, List<WebElement> webElementsList) {
        return WaitForFirstElement.waitForVisibilityOfFirstElement(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), webElementsList);
    }

    /**
     * Checks if any element identified by the given locators is visible.
     *
     * @param locators Locators identifying the elements to check.
     * @return true if any of the elements become visible within the wait time; false otherwise.
     */
    public boolean isAnyElementByLocatorVisible(By... locators) {
        return WaitForFirstLocator.waitForVisibilityOfFirstLocator(
                DriverManager.getInstance().getFluentWait(), locators);
    }

    /**
     * Checks if any element identified by the given locators is visible, considering a specific polling interval.
     *
     * @param pollingInterval The custom polling interval to wait for element visibility.
     * @param locators        Varargs of locators identifying the elements to check.
     * @return True if any of the elements become visible within the specified polling interval; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementByLocatorVisible(Duration pollingInterval, By... locators) {
        return WaitForFirstLocator.waitForVisibilityOfFirstLocator(
                DriverManager.getInstance().getFluentWait(pollingInterval), locators);
    }

    /**
     * Checks if any element identified by the given locators is visible,
     * considering both a custom timeout and polling interval.
     *
     * @param timeout         The custom timeout duration to wait for element visibility.
     * @param pollingInterval The custom polling interval to wait between checks.
     * @param locators        Varargs of locators identifying the elements to check.
     * @return True if any of the elements become visible within the specified timeout and polling intervals;
     * false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementByLocatorVisible(Duration timeout, Duration pollingInterval, By... locators) {
        return WaitForFirstLocator.waitForVisibilityOfFirstLocator(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), locators);
    }

    /**
     * Checks if any element identified by locators in a list is visible.
     *
     * @param locatorsList A list of locators identifying the elements to check.
     * @return True if any of the elements become visible within the default wait time; false otherwise.
     */
    public boolean isAnyElementByLocatorVisible(List<By> locatorsList) {
        return WaitForFirstLocator.waitForVisibilityOfFirstLocator(
                DriverManager.getInstance().getFluentWait(), locatorsList);
    }

    /**
     * Checks if any element identified by locators in a list is visible, considering a specific polling interval.
     *
     * @param pollingInterval The custom polling interval to wait for element visibility.
     * @param locatorsList    A list of locators identifying the elements to check.
     * @return True if any of the elements become visible within the specified polling interval; false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementByLocatorVisible(Duration pollingInterval, List<By> locatorsList) {
        return WaitForFirstLocator.waitForVisibilityOfFirstLocator(
                DriverManager.getInstance().getFluentWait(pollingInterval), locatorsList);
    }

    /**
     * Checks if any element identified by locators in a list is visible,
     * considering both a custom timeout and polling interval.
     *
     * @param timeout         The custom timeout duration to wait for element visibility.
     * @param pollingInterval The custom polling interval to wait between checks.
     * @param locatorsList    A list of locators identifying the elements to check.
     * @return True if any of the elements become visible within the specified timeout and polling intervals;
     * false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean isAnyElementByLocatorVisible(Duration timeout, Duration pollingInterval, List<By> locatorsList) {
        return WaitForFirstLocator.waitForVisibilityOfFirstLocator(
                DriverManager.getInstance().getFluentWait(timeout, pollingInterval), locatorsList);
    }

    /**
     * Checks the visibility of a specific web element.
     *
     * @param webElement The WebElement to check for visibility.
     * @return True if the element is visible; false otherwise.
     */
    public boolean isElementVisible(WebElement webElement) {
        try {
            InfoMessage.waitingForVisibilityOfElement(webElement);
            webDriverWait.until(ExpectedConditions.visibilityOf(webElement));
            InfoMessage.elementIsVisible(webElement);
            return webElement.isDisplayed();
        } catch (TimeoutException | NoSuchElementException exception) {
            ErrorMessage.caughtElementException(exception, webElement);
            return false;
        }
    }

    /**
     * Verifies if a specific number of WebElements in a list are visible.
     *
     * @param webElementsList  A list of WebElements to check for visibility.
     * @param numberOfElements The number of elements expected to be visible.
     * @return True if the number of visible elements matches the expected number; false otherwise.
     */
    public boolean isNumberOfElementsByWebElementsVisible(List<WebElement> webElementsList, int numberOfElements) {
        try {
            InfoMessage.waitingForVisibilityOfAllElementsByWebElement(webElementsList);
            List<WebElement> elements = webDriverWait.until(ExpectedConditions.visibilityOfAllElements(webElementsList));
            boolean areAllElementsVisible = elements.size() == numberOfElements;
            InfoMessage.elementsAreVisibleByWebElements(webElementsList);
            return areAllElementsVisible;
        } catch (NoSuchElementException | TimeoutException exception) {
            return false;
        }
    }

    /**
     * Checks if all WebElements in a list are visible.
     *
     * @param webElementsList A list of WebElements to check for visibility.
     * @return True if all elements in the list are visible; false otherwise.
     */
    public boolean isNumberOfElementsByWebElementsVisible(List<WebElement> webElementsList) {
        try {
            InfoMessage.waitingForVisibilityOfAllElementsByWebElement(webElementsList);
            List<WebElement> elements = webDriverWait.until(ExpectedConditions.visibilityOfAllElements(webElementsList));
            boolean areAllElementsVisible = elements.size() == webElementsList.size();
            InfoMessage.elementsAreVisibleByWebElements(webElementsList);
            return areAllElementsVisible;
        } catch (NoSuchElementException | TimeoutException exception) {
            return false;
        }
    }

    /**
     * Verifies if a specific number of elements identified by locators are visible.
     *
     * @param locatorsList             A list of locators identifying elements.
     * @param expectedNumberOfElements The expected number of visible elements.
     * @return True if the number of visible elements matches the expected number; false otherwise.
     */
    public boolean isNumberOfElementsByLocatorsVisible(List<By> locatorsList, int expectedNumberOfElements) {
        try {
            InfoMessage.waitingForVisibilityOfAllElementsByLocator(locatorsList);
            int visibleElementsCount = 0;
            for (By locator : locatorsList) {
                List<WebElement> elements = webDriverWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
                visibleElementsCount += elements.size();
            }
            boolean areAllElementsVisible = visibleElementsCount == expectedNumberOfElements;
            if (areAllElementsVisible) {
                InfoMessage.elementsAreVisibleByWebLocators(locatorsList);
            }
            return areAllElementsVisible;
        } catch (NoSuchElementException | TimeoutException exception) {
            return false;
        }
    }

    /**
     * Checks if all elements identified by a list of locators are visible.
     *
     * @param locatorsList A list of locators identifying elements.
     * @return True if all elements identified by the locators are visible; false otherwise.
     */
    public boolean isNumberOfElementsByLocatorsVisible(List<By> locatorsList) {
        try {
            InfoMessage.waitingForVisibilityOfAllElementsByLocator(locatorsList);
            int visibleElementsCount = 0;
            for (By locator : locatorsList) {
                List<WebElement> elements = webDriverWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
                visibleElementsCount += elements.size();
            }
            boolean areAllElementsVisible = visibleElementsCount == locatorsList.size();
            if (areAllElementsVisible) {
                InfoMessage.elementsAreVisibleByWebLocators(locatorsList);
            }
            return areAllElementsVisible;
        } catch (NoSuchElementException | TimeoutException exception) {
            return false;
        }
    }

    /**
     * Checks for the visibility of an element identified by a locator.
     *
     * @param locator The locator identifying the element.
     * @return True if the element is visible; false otherwise.
     */
    public boolean isElementVisible(By locator) {
        try {
            InfoMessage.waitingForVisibilityOfElement(locator);
            boolean isVisible = webDriverWait.until(ExpectedConditions.and(ExpectedConditions.presenceOfElementLocated(locator), ExpectedConditions.visibilityOfElementLocated(locator)));
            InfoMessage.elementIsVisible(locator);
            return isVisible;
        } catch (TimeoutException | NoSuchElementException exception) {
            ErrorMessage.caughtElementException(exception, locator);
            return false;
        }
    }

    /**
     * Checks for the invisibility of a specific web element.
     *
     * @param webElement The WebElement to check for invisibility.
     * @return True if the element is invisible; false otherwise.
     */
    public boolean invisibilityOfElement(WebElement webElement) {
        try {
            InfoMessage.waitingForElementToBecomeInvisible(webElement);
            boolean isVisible = webDriverWait.until(ExpectedConditions.invisibilityOf(webElement));
            InfoMessage.elementIsInvisible(webElement);
            return isVisible;
        } catch (TimeoutException | NoSuchElementException exception) {
            ErrorMessage.caughtElementException(exception, webElement);
            return false;
        }
    }

    /**
     * Checks for the invisibility of an element identified by a locator.
     *
     * @param locator The locator identifying the element.
     * @return True if the element is invisible; false otherwise.
     */
    public boolean invisibilityOfElement(By locator) {
        try {
            InfoMessage.waitingForElementToBecomeInvisible(locator);
            boolean isVisible = webDriverWait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
            InfoMessage.elementIsInvisible(locator);
            return isVisible;
        } catch (TimeoutException | NoSuchElementException exception) {
            ErrorMessage.caughtElementException(exception, locator);
            return false;
        }
    }
}