package com.demoappmobile.screenutilities.detection.wait;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import java.util.Arrays;
import java.util.function.Function;

/**
 * An abstract class that provides a foundational structure for implementing various wait strategies
 * in web automation tests.
 * This class defines utility methods to support waiting for certain conditions to be met
 * within web pages using {@link FluentWait}.
 */
public abstract class WaitUtilities {

    /**
     * Protected constructor to prevent instantiation of this utility class directly.
     */
    protected WaitUtilities() {
        // Protected constructor to prevent instantiation.
    }

    /**
     * Waits for a specified condition to be met within the constraints defined by a {@link FluentWait} instance.
     * This method provides a generic way to implement custom wait conditions
     * and handle {@link TimeoutException} gracefully.
     *
     * @param fluentWait The {@link FluentWait} instance specifying the wait conditions,
     *                   including timeout and polling interval.
     * @param condition  A {@link Function} representing the condition to wait for.
     *                   This function takes a {@link WebDriver} instance as input and returns a {@link Boolean}
     *                   indicating whether the condition is met.
     * @return {@code true} if the condition is met within the timeout specified in the {@link FluentWait} instance;
     * {@code false} if a {@link TimeoutException} is caught, indicating that the condition
     * was not met within the timeout period.
     */
    protected static boolean waitForCondition(FluentWait<WebDriver> fluentWait,
                                              Function<WebDriver, Boolean> condition) {
        try {
            return fluentWait.until(condition);
        } catch (TimeoutException timeoutException) {
            // TODO: Replace System.out.println with a proper logging mechanism.
            System.out.println("Exception while waiting: " + Arrays.toString(timeoutException.getStackTrace()));
            return false;
        }
    }
}